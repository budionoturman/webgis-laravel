<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class StatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // 1. pantai teluk penyu
        // 2. Benteng pendem
        // 3. Pantai Kamulyan
        // 4. Pulau Nusakambang
        // 5. Pantai Widarapayung
        // 6. Pantai ketapang Indah
        // 7. pantai Sodong
        // 8. Gunung Selok
        // 9. Pantai Buton
        // 10. Gunung Srandil
        // 11. Susur Sungai dan Batik mangrove
        // 12. Hutan Payau
        // 13. Air panas Cipari
        // 14. Curug Mandala
        // 15. Waduk Kubangkangkung
        // 16. Havana Hills
        // 17. Goa Masigitsela
        // 18. Museum Soesilo Soedirman
        // 19. Kemit Forest Education
        // 20. Pantai Congot jetis
        // 21. Pantai Bungso jetis
    }
}