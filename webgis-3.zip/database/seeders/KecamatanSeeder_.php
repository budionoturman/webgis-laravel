<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class HotelSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // 1. Dayaluhur
        // 2. Wanareja
        // 3. Majenang
        // 4. Cimanggu
        // 5. Karangpucung
        // 6. Cipari
        // 7. Sidareja
        // 8. Kedungreja
        // 9. Patimuan 
        // 10. Gandrungmangu
        // 11. Bantarsari
        // 12. Kawunganten
        // 13. Kampung laut
        // 14. Jeruklegi
        // 15. Kesugihan
        // 16. Adipala
        // 17. Maos
        // 18. Sampang
        // 19. Kroya
        // 20. Binangun
        // 21. Nusawungu
        // 22. Cilacap Selatan
        // 23. Cilacap Tengah
        // 24. Cilacap Utara
    }
}